from vcf import *
from conversion import *

__version__ = '1.3.1'
supported_ir_vcf_versions = ['0.1.2', '0.1.4']
